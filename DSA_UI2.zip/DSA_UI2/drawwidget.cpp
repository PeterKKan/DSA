#include "drawwidget.h"
#include <QDebug>
#include <QPainter>
#define W 1600
#define H 1200
using namespace std;

drawWidget::drawWidget(){
}

void drawWidget:: paintEvent(QPaintEvent*){
    QPainter* p = new QPainter();
    p->begin(this);
    fArray<fArray<int>*>* allLocations = new fArray<fArray<int>*>(gra->numVertex);
    for(int i = 0; i < courseForPaint->size; i++){
        for(int j = 0; j < courseForPaint->array[i]->size; j++){
            fArray<int>* location = new fArray<int>(2);
            location->array[0] = int((W/(courseForPaint->array[i]->size))*j+W/20);
            location->array[1] = int(H/(courseForPaint->size+1)*i+H/10);
            allLocations->array[courseForPaint->array[i]->array[j]] = location;
        }
    }
    for(int i = 0; i < courseForPaint->size; i++){
        switch (cnt%3) {
        case 0:
            p->setPen(QPen(Qt::red,3));
            break;
        case 1:
            p->setPen(QPen(Qt::green,3));
            break;
        case 2:
            p->setPen(QPen(Qt::blue,3));
            break;
        default:
            break;
        }
        for(int j = 0; j < courseForPaint->array[i]->size; j++){
            for (Edge e = gra->FirstEdge(courseForPaint->array[i]->array[j]); gra->isEdge(e) ; e = gra->NextEdge(e)) {
                int to = e.to;
                p->drawLine((W/(courseForPaint->array[i]->size))*j+W/20+W/40, H/(courseForPaint->size+1)*i+H/10,allLocations->array[to]->array[0]+W/40,allLocations->array[to]->array[1]);
            }
        }
        cnt++;
    }
    p->setPen(Qt::black);
    for(int i = 0; i < courseForPaint->size; i++){
        for(int j = 0; j < courseForPaint->array[i]->size; j++){
            p->drawText(int((W/(courseForPaint->array[i]->size))*j+W/20),int(H/(courseForPaint->size+1)*i+H/10),QString::number(gra->graList[courseForPaint->array[i]->array[j]].courseNum)+QString::fromStdString(".")+QString::fromStdString(gra->graList[courseForPaint->array[i]->array[j]].courseName));
        }
    }
    cnt = 0;
    p->end();
}
