#ifndef DRAWWIDGET_H
#define DRAWWIDGET_H
#include <QWidget>
#include <QPainter>
#include <iostream>
#include "farray.h"
#include "graph.h"
using namespace std;

class drawWidget:public QWidget{
    Q_OBJECT
public:
    void paintEvent(QPaintEvent*);
    drawWidget();
    fArray<fArray<int>*>* courseForPaint;
    Graphl* gra;
    int cnt = 0;
};

#endif // DRAWWIDGET_H
