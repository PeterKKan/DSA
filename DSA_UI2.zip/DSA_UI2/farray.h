#ifndef FARRAY_H
#define FARRAY_H
#include <iostream>
#include <cstring>
using namespace std;
template<class T>
class fArray{
public:
    int size; //里面元素的个数
    T* array;
    fArray(int len = 0){
        if (len == 0){
            array = NULL;
        }else{
            array = new T [len];
        }
        size = 0;
    }
    fArray(const fArray<T> &a){
        if (a.array){
            array = NULL;
            size = 0;
        }else{
            array = new T[a.size];
            memcpy(array, a.array, sizeof(T)*a.size);
            size = a.size;
        }
    }
    ~fArray(){
        if (array) delete [] array;
    }
    fArray & operator=(const fArray & a){
        if(array == a.array) // 防止a=a这样的赋值导致出错
            return *this;

        if(a.array == NULL) // 如果a里面的数组是空的
        {
            if(array)
                delete [] array; // 释放旧数组的资源

            array = NULL;
            array = 0;
            return *this;
        }

        if(size < a.size) // 如果原有空间足够大，就不用分配新的空间
        {
            if(array)
                delete [] array; // 释放旧数组的资源

            array = new int[a.size]; // 申请新的内存地址
        }

        memcpy(array, a.array, sizeof(int)*a.size);
        size = a.size;
        return *this;
    }
    //fArray & operator[](int i){
    //    return array[i];
    //}
    //void lengthen(){}

    void append(T item){
        if(array) // 如果数组不为空
        {
            T *tmpPtr = new T[size + 1]; // 重新分配空间
            // memcpy(tmpPtr, array, sizeof(int)*size); // 拷贝原数组内容
            for (int i = 0; i < size; i++) {
                tmpPtr[i] = array[i];
            }
            delete [] array;
            array = tmpPtr;
        }
        else // 如果数组本来就是空的
        {
            array = new T[1];
        }
        array[size++] = item;
    }
    void insert(T item, int location){
        if (array){
            if (location >=0 && location < size){
                T *tmpPtr = new T[size + 1];
                for (int i = 0; i < location; i++) {
                    tmpPtr[i] = array[i];
                }
                tmpPtr[location] = item;
                for (int i = location; i < size; i++) {
                    tmpPtr[i+1] = array[i];
                }
                delete [] array;
                array = tmpPtr;
                size++;
            } else if (location == size){
                append(item);
            }
        } else{
            if (location == 0){
                array = new int[1];
                array[size++] = item;
            }
        }
    }
    void del(int location){
        if (array && size){
            if (location >= 0 && location < size){
                T *tmpPtr = new T[size - 1];
                for (int i = 0; i < location; i++) {
                    tmpPtr[i] = array[i];
                }
                for (int i = location+1; i < size; i++) {
                    tmpPtr[i-1] = array[i];
                }
                delete [] array;
                array = tmpPtr;
                size--;
            }
        }
    }

    void delElement(T element){
        for (int i = 0; i < size; i++) {
            if (array[i] == element){
                del(i);
            }
        }
    }

    bool isIn(T item){
        for (int i = 0; i < size; i++) {
            if (array[i] == item){return true;}
        }
        return false;
    }

    void clear(){
        for (int i = size-1; i >=0; i--) {
            del(i);
        }
    }

    bool isEmpty(){
        return !size;
    }

    T findMin(){
        T min = array[0];
        for (int i = 0; i < size; i++) {
            if (array[i] < min){
                min = array[i];
            }
        }
        return min;
    }

    void printA(){
        for (int i = 0; i < size; i++) {
            cout << array[i] << "\t";
        }
    }

};
#endif // FARRAY_H
