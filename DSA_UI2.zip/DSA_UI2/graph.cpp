#include "mainwindow.h"
#include "graph.h"

#define W 1600
#define H 1200
using namespace std;

