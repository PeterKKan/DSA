#ifndef GRAPH_H
#define GRAPH_H
#include <iostream>
#include <iomanip>
#include "queue.h"
#include "stack.h"
#include "farray.h"
#include <QPushButton>
#define UNVISITED 0
#define VISITED 1
#define INFINITY 10000
using namespace std;

class Edge{            // 边类
public:
    int from, to, weight;
    Edge(){
        from = -1; to = -1; weight = 0;
    }
    Edge(int f, int t, int w){
        from = f; to = t; weight = w;
    }
};

class Graph{           // 图类
public:
    int numVertex;     // 节点数目
    int numEdge;       // 边数目
    int *Mark;         // 每个节点是否被访问过的数组
    int *Indegree;     // 每个节点入度的数组
    Graph(int numVert){
        numVertex = numVert;
        numEdge = 0;
        Indegree = new int[numVertex];
        Mark = new int[numVertex];
        for (int i = 0; i < numVertex; i++) {
            Mark[i] = UNVISITED;
            Indegree[i] = 0;
        }
    }

    ~Graph(){
        delete [] Mark;
        delete [] Indegree;
    }

    int VerticesNum(){
        return numVertex;
    }

    bool isEdge(Edge oneEdge){
        return oneEdge.weight > 0 && oneEdge.weight < INFINITY && oneEdge.to >= 0;
    }

    int FromVertex(Edge oneEdge){return oneEdge.from;}
    int ToVertex(Edge oneEdge){return oneEdge.to;}
    int Weight(Edge oneEdge){return oneEdge.weight;}

};



struct listUnit{   // 邻接表中边结点的结构体定义
    int vertex;
    int weight;
};

template<class Elem>
class Link{        // 链表元素类
public:
    Elem element;
    Link *next;
    Link(const Elem& elemval,Link *nextval = NULL){
        element = elemval;
        next = nextval;
    }
    Link(Link *nextval = NULL){
        next = nextval;
    }
};

template<class Elem>
class LList{        // 链表类
public:
    Link<Elem> *head;
    int courseNum;//课程编号
    string courseName;//课程名称
    float corseScore;//学分
    LList(){
        head = new Link<Elem>();
    }
};

class Graphl: public Graph{
public:
    double totalCredit = 0;
    LList<listUnit> *graList;  // 保存所有边表的数组
    Graphl(int numVert):Graph(numVert){
        graList = new LList<listUnit>[numVertex];
    }

    Edge FirstEdge(int oneVertex){  // 返回依附于oneVertex的第一条边
        Edge myEdge;
        myEdge.weight = 0;
        myEdge.from = oneVertex;
        Link<listUnit> *temp = graList[oneVertex].head;
        if (temp -> next != NULL){
            myEdge.to = temp->next->element.vertex;
            myEdge.weight = temp->next->element.weight;
        }
        return myEdge;
    }

    Edge NextEdge(Edge preEdge){    // 返回与preEdge有相同顶点的下一条边
        Edge myEdge;
        myEdge.from = preEdge.from;
        myEdge.weight = 0;
        Link<listUnit> *temp = graList[preEdge.from].head;
        while (temp->next != NULL && temp->next->element.vertex <= preEdge.to){
            temp = temp->next;
        }
        if (temp->next != NULL){
            myEdge.to = temp->next->element.vertex;
            myEdge.weight = temp->next->element.weight;
        }
        return myEdge;
    }

    void setEdge(int from, int to, int weight){     // 为图设置一条边
        Link<listUnit> *temp = graList[from].head;
        while (temp->next != NULL && temp->next->element.vertex < to){
            temp = temp->next;
        }   // 确定边在边表中的位置，to的序号按增序排列
        if (temp->next == NULL){        // 若新边不存在且是最后一条边
                temp->next = new Link<listUnit>();
                temp->next->element.vertex = to;
                temp->next->element.weight = weight;
                numEdge++;
                Indegree[to]++;
                return;
        }
        if (temp->next->element.vertex == to){     // 边已存在的话，只需改变权值
            temp->next->element.weight = weight;
            return;
        }
        if (temp->next->element.vertex > to){      // 新边不存在且后面还有边
            Link<listUnit> *other = temp->next;
            temp->next = new Link<listUnit>();
            temp->next->element.vertex = to;
            temp->next->element.weight = weight;
            temp->next->next = other;
            numEdge++;
            Indegree[to]++;
            return;
        }
    }

    void delEdge(int from, int to){     // 删除一条边
        Link<listUnit> *temp = graList[from].head;
        while (temp->next != NULL && temp->next->element.vertex < to){
            temp = temp->next;
        }
        if (temp->next == NULL)return;
        if (temp->next->element.vertex > to)return;
        if (temp->next->element.vertex == to){
            Link<listUnit> *other = temp->next->next;
            delete temp->next;
            temp->next = other;
            numEdge--;
            Indegree[to]--;
            return;
        }
    }

    bool stillUnvisited(){
        for (int i = 0; i < VerticesNum(); i++) {
            if (Mark[i] == UNVISITED){
                return true;
            }
        }
        return false;
    }

};




struct statusPerTerm{
    fArray<int>* Open;
    fArray<int>* Close;
    fArray<int>* Selected;
    fArray<fArray<int>*>* CourseFor8;
    int UnselectedNum;
    int Cnt;
    int * mark;
    int * Indegree;
    statusPerTerm(fArray<int>* open,fArray<int>* close,fArray<fArray<int>*>* courseFor8,int unselectedNum,int cnt,int * Mark,int* indegree,int Vnum){
        Open = new fArray<int>();
        for (int i = 0; i < open->size; i++) {
            Open->append(open->array[i]);
        }
        Close = new fArray<int>();
        for (int i = 0; i < close->size; i++) {
            Close->append(close->array[i]);
        }
        Selected = new fArray<int>();
        CourseFor8 = new fArray<fArray<int>*>();
        for (int i = 0; i < courseFor8->size; i++) {
            auto*coursePerTerm = new fArray<int>();
            for (int j = 0; j < courseFor8->array[i]->size; ++j) {
                coursePerTerm->append(courseFor8->array[i]->array[j]);
            }
            CourseFor8->append(coursePerTerm);
        }
        Cnt = cnt;
        UnselectedNum = unselectedNum;
        mark = new int[Vnum];
        Indegree = new int[Vnum];
        for (int i = 0; i < Vnum; i++) {
            mark[i] = Mark[i];
            Indegree[i] = indegree[i];
        }
    }
};



#endif // GRAPH_H
