#ifndef LINKED_H
#define LINKED_H
#include <iostream>
using namespace std;

template<class T> class LinkNode{
public:
    T data;
    LinkNode<T> *next;
    LinkNode(const T info, LinkNode<T> *nextValue = NULL){
        data = info;
        next = nextValue;
    }
    LinkNode(LinkNode<T> *nextValue = NULL){
        next = nextValue;
    }
};

template<class T>class lnkList{
private:
    LinkNode<T> *head, *tail;
    int size = 0;
    LinkNode<T> *setPos(const int p){
        int count = 0;
        if (p == -1){       // 若p为-1则定位到头节点
            return head;
        }
        LinkNode<T> *tmp = head->next;     // 若p为0则定位到第一个节点
        while (tmp != NULL && count < p){
            tmp = tmp->next;
            count++;
        }
        return tmp;
    }   // 返回线性表指向第p个元素的指针值
public:
    lnkList(){
        head = tail = new LinkNode<T>;
    }
    ~lnkList(){
        LinkNode<T> *tmp;
        while (head != NULL){
            tmp = head;
            head = head->next;
            delete tmp;
        }
    }
    LinkNode<T> returnHead(){
        return head;
    }
    bool isEmpty(){
        return !size;
    }
    void clear();
    int length(){
        return size;
    }
    bool append(const T value){
        insert(size,value);
        return true;
    }
    bool insert(const int i, const T value){
        LinkNode<T> *p, *q;
        if ((p = setPos(i-1)) == NULL){
            cout << "非法插入点" << endl;
            return false;
        }
        q = new LinkNode<T>(value, p->next);
        p->next = q;
        if (p == tail)
            tail = q;
        size++;
        return true;
    }
    bool del(const int i){
        LinkNode<T> *p, *q;
        if ((p = setPos(i-1)) == NULL || p == tail){
            cout << "非法删除点" << endl;
            return false;
        }
        q = p->next;        // q是真正的待删除节点
        if (q == tail){
            tail = p;
            p->next = NULL;
            delete q;
        } else if (q != NULL){
            p->next = q->next;
            delete q;
        }
        size--;
        return true;
    }
    void getValue(const int p, T& value){
        LinkNode<T>*tmp = head;
        for (int i = 0; i <= p; i++) {
            tmp = tmp->next;
        }
        value = tmp->data;
    }
    bool getPos(int&p, const T value);
    void printL(){
        LinkNode<T> *tmp = head->next;
        while (tmp != NULL){
            cout << tmp->data << " ";
            tmp = tmp->next;
        }
    }
};

#endif // LINKED_H
