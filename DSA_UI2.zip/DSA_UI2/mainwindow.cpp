#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
#include <fstream> // 用于读写文件
#include <unistd.h>
#include <QTime>
#include <QInputDialog>
#define W 1600
#define H 1200
using namespace std;

Graphl* init();  // 用于初始化图的函数

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setFixedSize(W,H);
    setWindowTitle("某科学的选课系统");

    CourseGraph = init();
    courseForPaint = new fArray<fArray<int>*>;
    startButton = new QPushButton("button_ptr",this);
    startButton->setText("开始选课");
    startButton->move(W/2-W/20,H*3/4);
    startButton->setFixedSize(W/10,H/20);
    confirmButton = new QPushButton("确认选课",this);
    confirmButton->hide();
    retreatButton = new QPushButton("撤回",this);
    retreatButton->hide();
    adviceButton = new QPushButton("推荐选课",this);
    adviceButton->hide();
    terminateButton = new QPushButton("结束选课",this);
    terminateButton->hide();
    drawButton = new QPushButton("绘拓扑图",this);
    drawButton->hide();
    allSelectButton = new QPushButton("全选",this);
    allSelectButton->hide();
    allUnselectedButton = new QPushButton("全不选",this);
    allUnselectedButton->hide();
    UnselectNumLabel = new QLabel(this);
    UnselectNumLabel->hide();
    hintLabel = new QLabel(this);
    hintLabel->hide();
    terminateLabel = new QLabel(this);
    terminateLabel->hide();
    terminateLabel2 = new QLabel(this);
    terminateLabel2->hide();
    endLabel = new QLabel(this);
    endLabel->hide();
    drawwidget = new drawWidget();
    drawwidget->hide();
    drawwidget->setWindowTitle("某科学的拓扑绘图");
    drawwidget->setFixedSize(W,H);
    drawwidget->gra = CourseGraph;


    connect(startButton,&QPushButton::pressed,this,&MainWindow::prepareMain);
    connect(confirmButton,&QPushButton::clicked,this,&MainWindow::getSelected);
    connect(retreatButton,&QPushButton::clicked,this,&MainWindow::sendRetreatSig);
    connect(adviceButton,&QPushButton::clicked,this,&MainWindow::sendAdviceSig);
    connect(terminateButton,&QPushButton::clicked,this,&MainWindow::goToEnd);
    connect(allSelectButton,&QPushButton::clicked,this,&MainWindow::allselect);
    connect(allUnselectedButton,&QPushButton::clicked,this,&MainWindow::allunselect);
    connect(drawButton,&QPushButton::clicked,drawwidget,&drawWidget::show);

    open = new fArray<int>();
    close = new fArray<int>();
    selected = new fArray<int>();
    courseFor8 = new fArray<fArray<int>*>();
    unselectedNum = CourseGraph->VerticesNum();
    cnt = 0;
    allStatus = new fArray<statusPerTerm*>();
    creditForEachTerm = new fArray<float>();
    temp = new int[CourseGraph->numVertex];
    for (int i = 0; i <CourseGraph->numVertex; i++) {
        temp[i] = CourseGraph->Indegree[i];
    }
    QPixmap pixmap = QPixmap("../DSA_UI2/logo mini.PNG").scaled(this->size());
    //QPixmap pixmap = QPixmap("../DSA_UI2/logo.JPG").scaled(this->size());
    //QPixmap pixmap = QPixmap("../DSA_UI2/logo2.PNG").scaled(this->size());
    QPalette palette = QPalette(this->palette());
    palette.setBrush(QPalette::Background,QBrush(pixmap));
    this->setPalette(palette);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow:: prepareMain(){
    startButton->hide();

    for (int i = 0; i < CourseGraph->VerticesNum() ; i++) {    // 将所有MARK重置
        CourseGraph->Mark[i] = UNVISITED;
    }
    groupbox = new QGroupBox(this);
    groupbox->resize(W/2,H/10*9);
    groupbox->move(0,0);
    vlayout = new QVBoxLayout(this);

    confirmButton->setFixedSize(int(W/12),int(H/24));
    confirmButton->move(0,H*9/10);

    retreatButton->setFixedSize(int(W/12),int(H/24));
    retreatButton->move(W/60+W/12,H*9/10);

    adviceButton->setFixedSize(int(W/12),int(H/24));
    adviceButton->move(W/30+W/6,H*9/10);

    terminateButton->setFixedSize(int(W/12),int(H/24));
    terminateButton->move(0,H*9/10);

    drawButton->setFixedSize(int(W/12),int(H/24));
    drawButton->move(W/15+W/3,H*9/10+H/20);

    UnselectNumLabel->setFixedSize(W/4,H/24);
    UnselectNumLabel->move(0,H*9/10+H/48+H/96);

    hintLabel->setFixedSize(W/40*3+W/4,H/24);
    hintLabel->move(0,H*9/10+H/48+H/24);

    allSelectButton->setFixedSize(int(W/12),int(H/24));
    allSelectButton->move(W/20+W/4,H*9/10);

    allUnselectedButton->setFixedSize(int(W/12),int(H/24));
    allUnselectedButton->move(W/15+W/3,H*9/10);

    terminateLabel->setFixedSize(W/2,H/24);
    terminateLabel->move(W/20,H/2-H/5);
    terminateLabel2->setFixedSize(W/2,H/24);
    terminateLabel2->move(W/20,H/2-H/5+H/24);
    UnselectNumLabel->setText(QString::fromStdString("还没有选择课程的门数：")+QString::number(unselectedNum));

    for(int i = 0; i < 8; i++){
        alltextbrowser[i] = new QTextBrowser(this);
        alltextbrowser[i]->resize(W/3,H/12);
        alltextbrowser[i]->move(W*6/10,H/16*(i*2)+H/80);
        alltextbrowser[i]->show();
    }

    for(int i = 0; i < 8; i++){
        allLabel[i] = new QLabel(this);
        allLabel[i]->resize(W/3,H/15);
        allLabel[i]->move(W*6/10,H/16*(i*2)+H/13);
    }

    printOpen();
}

void MainWindow:: topSortFind0(){
    for (int i = 0; i < CourseGraph->VerticesNum(); i++) {
        // 将当前入度为0的节点装入open
        if (CourseGraph->Indegree[i] == 0 && CourseGraph->Mark[i] == UNVISITED){
            CourseGraph->Mark[i] = VISITED;
            open->append(i);
        }
    }
}

void MainWindow::printOpen(){
    courseForPaint = TopsortToGroup(CourseGraph);
    drawwidget->courseForPaint = courseForPaint;
    drawwidget->update();
    topSortFind0();

    float creditForThisTerm = 0;
    QString boxTitle = "第"+QString::number(cnt+1)+"学期，从以下可选课程中选择课程";
    groupbox->setTitle(boxTitle);
    for(int i = 0; i < open->size; i++){
        allcheckbox[open->array[i]]->show();
        vlayout->addWidget(allcheckbox[open->array[i]]);
    }
    hintLabel->show();
    terminateButton->hide();
    terminateLabel->hide();
    terminateLabel2->hide();
    retreatButton->show();
    confirmButton->show();
    adviceButton->show();
    drawButton->show();
    allSelectButton->show();
    allUnselectedButton->show();
    groupbox->setLayout(vlayout);
    groupbox->show();
    UnselectNumLabel->show();
    UnselectNumLabel->setText(QString::fromStdString("还没有选择课程的门数：")+QString::number(unselectedNum));
    hintLabel->setText(QString::fromStdString("建议每学期学分不超过 280 / 16 = 17"));
    coursePerTerm = new fArray<int>();


    for(int i = 0; i < 8; i++){
        alltextbrowser[i]->clear();
    }
    for(int i = 0; i < courseFor8->size; i++){
        for(int j = 0; j < courseFor8->array[i]->size; j++){
            alltextbrowser[i]->insertPlainText(QString::fromStdString(CourseGraph->graList[courseFor8->array[i]->array[j]].courseName)+"    ");
        }
    }
    for(int i = 0; i < 8; i++){
        allLabel[i]->hide();
    }
    creditForEachTerm->clear();
    for(int i = 0; i < courseFor8->size; i++){
        for(int j = 0; j < courseFor8->array[i]->size; j++){
            creditForThisTerm += CourseGraph->graList[courseFor8->array[i]->array[j]].corseScore;
        }
        allLabel[i]->setText(QString::fromStdString("第")+QString::number(i+1)+QString::fromStdString("学期学分：")+QString::number(creditForThisTerm));
        allLabel[i]->show();
        if (creditForThisTerm > 17){
            allLabel[i]->setStyleSheet( " color:orange; " );
        }else{
            allLabel[i]->setStyleSheet( " color:green; " );
        }
        creditForEachTerm->append(creditForThisTerm);
        creditForThisTerm = 0;
    }
    for(int i = 0; i < CourseGraph->numVertex; i++){
        allcheckbox[i]->hide();
    }
    for(int i = 0; i < open->size; i++){
        allcheckbox[open->array[i]]->show();
    }
    for (int i = 0; i < CourseGraph->numVertex; i++){
        allcheckbox[i]->setChecked(0);
    }
    if(cnt == 8 && unselectedNum == 0){
        groupbox->hide();
        adviceButton->hide();
        confirmButton->hide();
        allSelectButton->hide();
        allUnselectedButton->hide();
        for(int i = 0; i < 8; i++){
            if(creditForEachTerm->array[i] > 17){
                terminateLabel2->setText(QString::fromStdString("你有的学期学分超过了17，可能会很累！"));
                terminateLabel2->show();
                break;
            }
        }
        terminateButton->show();
        terminateLabel->setText(QString::fromStdString("已经选完了8学期而且没有剩余的课可以选，是否结束选课？"));
        terminateLabel->show();
        drawButton->hide();
    }
    if(cnt == 8 && unselectedNum != 0){
        terminateLabel->setText(QString::fromStdString("已经选完了8学期但是还有剩余的课可以选，请回撤"));
        terminateLabel->show();
        groupbox->hide();
        adviceButton->hide();
        confirmButton->hide();
        allSelectButton->hide();
        allUnselectedButton->hide();
    }
    if(cnt < 8 && unselectedNum == 0){
        terminateLabel->setText(QString::fromStdString("你只选了")+QString::number(cnt)+QString::fromStdString("/8学期就选完了所有课，确定这么做吗？"));
        terminateLabel->show();
        terminateLabel2->setText(QString::fromStdString("可能会很累！"));
        terminateLabel2->show();
        groupbox->hide();
        adviceButton->hide();
        confirmButton->hide();
        allSelectButton->hide();
        allUnselectedButton->hide();
        terminateButton->show();
        drawButton->hide();
    }
}

void MainWindow::goToEnd(){
    hintLabel->hide();
    confirmButton->hide();
    retreatButton->hide();
    adviceButton->hide();
    terminateButton->hide();
    terminateLabel->hide();
    terminateLabel2->hide();
    UnselectNumLabel->hide();
    endLabel->setText(QString::fromStdString("你已完成选课，结果如下："));
    endLabel->resize(W/4,H/20);
    endLabel->move(W/3,H/20);
    endLabel->show();

    for(int i = 0; i < 8; i++){
        alltextbrowser[i]->resize(W/2,H/12);
        alltextbrowser[i]->move(W/8,H/10*i+H/10);
    }

    for(int i = 0; i < 8; i++){
        allLabel[i]->setStyleSheet( " color:black; " );
        allLabel[i]->resize(W/3,H/15);
        allLabel[i]->move(W/3*2-H/20,H/10*i+H/10+int(H/80));
    }
}

void MainWindow:: getSelected(){
    for(int i = 0; i < open->size; i++){
        if(allcheckbox[open->array[i]]->isChecked()){
            selected->append(open->array[i]);
            coursePerTerm->append(open->array[i]);
        }
    }
    unselectedNum -= selected->size;

    if (!coursePerTerm->isEmpty()){courseFor8->append(coursePerTerm);cnt++;}
    while (!selected->isEmpty()){
        open->delElement(selected->array[0]);
        close->append(selected->array[0]);

        // 将边删去
        for (Edge e = CourseGraph->FirstEdge(selected->array[0]); CourseGraph->isEdge(e) ; e = CourseGraph->NextEdge(e)) {
            CourseGraph->Indegree[CourseGraph->ToVertex(e)]--;
        }
        selected->del(0);
    }
    // 保存状态
    auto* status = new statusPerTerm(open,close,courseFor8,unselectedNum,cnt,CourseGraph->Mark,CourseGraph->Indegree,CourseGraph->numVertex);
    allStatus->append(status);
    printOpen();
}

void MainWindow::sendRetreatSig(){
    int retreat = QInputDialog::getInt(NULL,QString::fromStdString("撤回"),QString::fromStdString("选择回退到的学期"),1,1,cnt+1);
    // 读取状态
    open->clear();
    close->clear();
    courseFor8->clear();
    selected->clear();
    if (retreat != 1){
        for (int i = 0; i < allStatus->array[retreat-2]->Open->size; i++) {
            open->append(allStatus->array[retreat-2]->Open->array[i]);
        }
        for (int i = 0; i < allStatus->array[retreat-2]->Close->size; i++) {
            close->append(allStatus->array[retreat-2]->Close->array[i]);
        }
        for (int i = 0; i < allStatus->array[retreat-2]->CourseFor8->size; i++) {
            coursePerTerm = new fArray<int>();
            for (int j = 0; j < allStatus->array[retreat-2]->CourseFor8->array[i]->size; j++) {
                coursePerTerm->append(allStatus->array[retreat-2]->CourseFor8->array[i]->array[j]);
            }
            courseFor8->append(coursePerTerm);
        }
        unselectedNum = allStatus->array[retreat-2]->UnselectedNum;
        cnt = allStatus->array[retreat-2]->Cnt;
        for (int i = 0; i < CourseGraph->numVertex; i++) {
            CourseGraph->Mark[i] = allStatus->array[retreat-2]->mark[i];
            CourseGraph->Indegree[i] =  allStatus->array[retreat-2]->Indegree[i];
        }
    } else{
        unselectedNum =CourseGraph->numVertex;
        cnt = 0;
        for (int i = 0; i < CourseGraph->VerticesNum() ; i++) {    // 将所有MARK重置
            CourseGraph->Mark[i] = UNVISITED;
            CourseGraph->Indegree[i] = temp[i];
        }
    }
    // 删除allstatus中的回退后的多余状态
    for (int i = allStatus->size-1; i >=retreat-1; i--) {
        allStatus->del(i);
    }
    printOpen();
}

void MainWindow::sendAdviceSig(){
    selected->clear();
    coursePerTerm->clear();
    auto* status4recommend = new statusPerTerm(open,close,courseFor8,unselectedNum,cnt,CourseGraph->Mark,CourseGraph->Indegree,CourseGraph->numVertex);
    int currentTerm = cnt;
    int recommendTermNum = 7 - currentTerm + 1;
    auto* coursePerTerm4recommend = new fArray<int>;
    auto* topList = new fArray<int>();
    for (int i = 0; i < open->size; i++) {
        coursePerTerm4recommend->append(open->array[i]);
        topList->append(open->array[i]);
    }
    auto* courseForRecommend = new fArray<fArray<int>*>();

    //拓扑
    while (CourseGraph->stillUnvisited()){
        for (int i = 0; i < CourseGraph->VerticesNum(); i++) {
            // 将当前入度为0的节点装入
            if (CourseGraph->Indegree[i] == 0 && CourseGraph->Mark[i] == UNVISITED){
                CourseGraph->Mark[i] = VISITED;
                coursePerTerm4recommend->append(i);
                topList->append(i);
            }
        }

        for (int i = 0; i < coursePerTerm4recommend->size; i++) {
            // 将边删去
            int v = coursePerTerm4recommend->array[i];
            for (Edge e = CourseGraph->FirstEdge(v); CourseGraph->isEdge(e); e = CourseGraph->NextEdge(e)) {
                CourseGraph->Indegree[CourseGraph->ToVertex(e)]--;
            }
        }
        courseForRecommend->append(coursePerTerm4recommend);
        coursePerTerm4recommend = new fArray<int>;
    }
    //分配
    //初始化
    auto* fakeSelections = new fArray<fArray<int>*>();
    fArray<int>* fakeSelectionPerTerm;
    for (int i = 0; i < recommendTermNum ; i++) {
        fakeSelectionPerTerm = new fArray<int>;
        fakeSelections->append(fakeSelectionPerTerm);
    }

    if (fakeSelections->size <= courseForRecommend->size){
        for (int i = 0; i < fakeSelections->size; i++) {
            for (int j = 0; j < courseForRecommend->array[i]->size; j++) {
                fakeSelections->array[i]->append(courseForRecommend->array[i]->array[j]);
            }
        }
    }else{
        int* NumsForEachRecommend = new int[recommendTermNum];//保存推荐的每学期课程数
        int* restrict = new int[courseForRecommend->size];//复制一个拓扑排序每行大小
        for (int i = 0; i < courseForRecommend->size; i++) {
            restrict[i] = courseForRecommend->array[i]->size;
        }
        distribute(NumsForEachRecommend, recommendTermNum, restrict, courseForRecommend->size);
        for (int i = 0; i < recommendTermNum; i++) {
            for (int j = 0; j < NumsForEachRecommend[i]; j++) {
                //cout<<topList->array[0];
                fakeSelections->array[i]->append(topList->array[0]);
                topList->del(0);
            }
        }
    }
    for (int i = 0; i < CourseGraph->numVertex; i++) {
        CourseGraph->Mark[i] = status4recommend->mark[i];
        CourseGraph->Indegree[i] =  status4recommend->Indegree[i];
    }
    //推荐选课
    for (int i = 0; i < fakeSelections->size; i++) {
        selected->clear();
        coursePerTerm = new fArray<int>();
        for (int j = 0; j < fakeSelections->array[i]->size; j++) {
            selected->append(fakeSelections->array[i]->array[j]);
            coursePerTerm->append(fakeSelections->array[i]->array[j]);
        }
        unselectedNum -= selected->size;
        if (!coursePerTerm->isEmpty()){courseFor8->append(coursePerTerm);cnt++;}
        while (!selected->isEmpty()){
            open->delElement(selected->array[0]);
            close->append(selected->array[0]);
            // 将边删去
            for (Edge e = CourseGraph->FirstEdge(selected->array[0]); CourseGraph->isEdge(e) ; e = CourseGraph->NextEdge(e)) {
                CourseGraph->Indegree[CourseGraph->ToVertex(e)]--;
            }
            selected->del(0);
        }
        // 保存状态
        auto* status = new statusPerTerm(open,close,courseFor8,unselectedNum,cnt,CourseGraph->Mark,CourseGraph->Indegree,CourseGraph->numVertex);
        allStatus->append(status);
        printOpen();
        }

}

void MainWindow::allselect(){
    for(int i = 0; i < open->size; i++){
        allcheckbox[open->array[i]]->setChecked(1);
    }
}

void MainWindow::allunselect(){
    for(int i = 0; i < open->size; i++){
        allcheckbox[open->array[i]]->setChecked(0);
    }
}

Graphl* MainWindow:: init(){
    int courseMaxNum;  // 课程总数
    fstream ifile;
    ifile.open("../DSA_UI2/course.txt", ios::in);
    ifile >> courseMaxNum;
    Graphl*G = new Graphl(courseMaxNum);
    for (int i = 0; i < courseMaxNum; i++) {
        ifile >> G->graList[i].courseNum >> G->graList[i].courseName >> G->graList[i].corseScore;
        G->totalCredit += G->graList[i].corseScore;
        allcheckbox[i] = new QCheckBox("课程编号："+QString::number(G->graList[i].courseNum)+"\t课程名称："+QString::fromStdString(G->graList[i].courseName)+"\t本课学分："+QString::number(G->graList[i].corseScore),this);
        allcheckbox[i]->hide();
    }
    while (!ifile.eof()){
        int from, to;
        ifile >> from >> to;
        G->setEdge(from,to,1);
    }
    ifile.close();
    return G;
}

void MainWindow:: distribute(int *nums, int terms, int* restrict, int resSize){
    int maxNumIndex = 0;
    int maxNum = 0;
    int cut = terms - resSize;
    auto* cutting = new fArray<int>();
    for (int i = 0; i < resSize; i++) {
        cutting->append(restrict[i]);
    }
    int shang = 0;
    int yushu = 0;

    while (cut != 0){
        maxNumIndex = 0;
        maxNum = 0;
        //找最大的
        for (int i = 0; i < cutting->size; i++) {
            if (cutting->array[i] >= cutting->array[maxNumIndex]){
                maxNumIndex = i;
                maxNum = cutting->array[i];
            }
        }
        shang = maxNum / 2;
        yushu = maxNum % 2;
        if (yushu){
            cutting->insert(shang,maxNumIndex);
            cutting->insert(shang+1,maxNumIndex);
        } else{
            cutting->insert(shang,maxNumIndex);
            cutting->insert(shang,maxNumIndex);
        }
        cutting->del(maxNumIndex+2);
        cut --;
    }
    for (int i = 0; i < terms; i++) {
        nums[i] = cutting->array[i];
    }
}

fArray<fArray<int>*>* MainWindow:: TopsortToGroup(Graphl*G){
    int* tempIndegree;
    tempIndegree = new int[G->numVertex];
    for (int i = 0; i < G->numVertex ; i++) {
        tempIndegree[i] = G->Indegree[i];
    }
    int* tempMark;
    tempMark = new int[G->numVertex];
    for (int i = 0; i < G->numVertex ; i++) {
        tempMark[i] = G->Mark[i];
    }
    fArray<fArray<int>*>* course8Term = new fArray<fArray<int>*>();
    fArray<int>* courseEachTerm;

    for(int i = 0; i < open->size; i++){
        G->Mark[open->array[i]] = UNVISITED;
    }
    while(G->stillUnvisited()){
        courseEachTerm = new fArray<int>();
        for (int i = 0; i < G->numVertex; i++) {
            // 将当前入度为0的节点装入S1
            if (G->Indegree[i] == 0 && G->Mark[i] == UNVISITED){
                G->Mark[i] = VISITED;
                courseEachTerm->append(i);
            }
        }
        course8Term->append(courseEachTerm);
        for(int i = 0; i < courseEachTerm->size; i++){
            //删除边
            int v = courseEachTerm->array[i];
            for (Edge e = G->FirstEdge(v); G->isEdge(e) ; e = G->NextEdge(e)) {
                G->Indegree[G->ToVertex(e)]--;
            }
        }
    }

    for (int i = 0; i < G->numVertex ; i++) {
        G->Indegree[i] = tempIndegree[i];
    }
    for (int i = 0; i < G->numVertex ; i++) {
        G->Mark[i] = tempMark[i];
    }
    return course8Term;
}

