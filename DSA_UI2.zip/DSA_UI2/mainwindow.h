#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "graph.h"
#include "drawwidget.h"
#include <QMainWindow>
#include <QPushButton>
#include <QCheckBox>
#include <QBoxLayout>
#include <QGroupBox>
#include <QTextBrowser>
#include <QLabel>
#include <QWidget>
#include <QPainter>
#include <QPixmap>
#include <QPalette>
using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    Ui::MainWindow *ui;
    QPushButton* startButton;
    void prepareMain();
    void getSelected();
    void sendRetreatSig();
    void sendAdviceSig();
    void goToEnd();
    void allselect();
    void allunselect();
    Graphl* CourseGraph;
    QCheckBox *allcheckbox[100];
    QTextBrowser *alltextbrowser[8];
    QGroupBox *groupbox;
    QVBoxLayout *vlayout;
    QPushButton* confirmButton;
    QPushButton* retreatButton;
    QPushButton* adviceButton;
    QPushButton* terminateButton;
    QPushButton* drawButton;
    QPushButton* allSelectButton;
    QPushButton* allUnselectedButton;
    QLabel* UnselectNumLabel;
    QLabel* hintLabel;
    QLabel* terminateLabel;
    QLabel* terminateLabel2;
    QLabel* allLabel[8];
    QLabel* endLabel;
    drawWidget* drawwidget;


    void topSortFind0();

    void printOpen();

    void distribute(int *nums, int terms, int* restrict, int resSize);

    //用户选课的函数
    void selectTopsortToGroup();

    Graphl* init();
    fArray<fArray<int>*>*TopsortToGroup(Graphl*G);
    fArray<fArray<int>*>* courseForPaint;

    fArray<int>* open; // 用于储存可被选择的课程的数组
    fArray<int>* close; // 用于储存结果的数组
    fArray<int>* selected; // 用于保存用户选择的课程
    fArray<int>* coursePerTerm;
    fArray<fArray<int>*>* courseFor8; // 8个学期的课程选择情况汇总
    int unselectedNum; // 还没有选的课的数量
    int cnt;//记学期数
    fArray<statusPerTerm*>* allStatus;// 储存所有学期的选课状态
    fArray<float>* creditForEachTerm;
    int* temp;//temp是用来存放G Indegree的变量，在撤回学期==1时使用
    int ButtonSig;
signals:


private:

};


#endif // MAINWINDOW_H
