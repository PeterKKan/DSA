#ifndef QUEUE_H
#define QUEUE_H
#include "linked.h"
using namespace std;
template<class T>
class lnkQueue{
private:
    int size;
    LinkNode<T> *front;        // 队头指针
    LinkNode<T> *rear;         // 队尾指针
public:
    lnkQueue(){
        size = 0;
        front = rear = NULL;
    }
    ~lnkQueue(){
        clear();
    }
    void clear(){
        while (front != NULL){
            rear = front;
            front = front->next;
            delete rear;
        }
        rear = NULL;
        size = 0;
    }
    bool enQueue(const T item){
        if (rear == NULL){
            front = rear = new LinkNode<T>(item, NULL);
        } else{
            rear->next = new LinkNode<T>(item, NULL);
            rear = rear->next;
        }
        size++;
        return true;
    }
    bool deQueue(T& item){
        LinkNode<T> *tmp;
        if (size == 0){
            cout << "队列为空" << endl;
            return false;
        }
        item = front->data;
        tmp = front;
        front = front->next;
        delete tmp;
        if (front == NULL){
            rear = NULL;
        }
        size--;
        return true;
    }

    bool getFront(T& item){
        if (size == 0){
            cout << "队列为空" << endl;
            return false;
        }
        item = front->data;
        return true;
    }

    bool isEmpty(){
        return !size;
    }

    void printQ(){
        LinkNode<T>* tmp;
        tmp = front;
        while (tmp != NULL){
            cout << tmp->data << " ";
            tmp = tmp->next;
        }
        cout << "Queue Printed  " << "";
    };
};

#endif // QUEUE_H
