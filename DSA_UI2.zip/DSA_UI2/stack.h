#ifndef STACK_H
#define STACK_H
#include "linked.h"
using namespace std;
template<class T>
class lnkStack{
private:
    LinkNode<T> *top;
    int size;
public:
    lnkStack(){
        top = NULL;
        size = 0;
    }
    ~lnkStack(){
        //clear();
    }
    void clear(){
        while (top != NULL){
            LinkNode<T> *tmp = top;
            top = top->next;
            delete tmp;
        }
        size = 0;
    }
    bool push(const T item){
        LinkNode<T> *tmp = new LinkNode<T>(item, top);
        top = tmp;
        size++;
        return true;
    }
    bool pop(T&item){
        LinkNode<T> *tmp;
        if (size == 0){
            cout << "栈为空" << endl;
            return false;
        }
        item = top->data;
        tmp = top->next;
        delete top;
        top = tmp;
        size--;
        return true;
    }
    bool getTop(T&item){
        if (size == 0){
            cout << "栈为空" << endl;
            return false;
        }
        item = top->data;
        return true;
    }
    void printS(){
        LinkNode<T>* tmp;
        tmp = top;
        while (tmp != NULL){
            cout << tmp->data << " ";
            tmp = tmp->next;
        }
        cout << "Stack Printed " << endl;
    };
    int getSize(){
        return size;
    }
    bool isEmpty(){
        return !size;
    }
};
#endif // STACK_H
